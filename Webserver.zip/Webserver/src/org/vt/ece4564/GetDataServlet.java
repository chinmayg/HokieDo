package org.vt.ece4564;

import javax.servlet.http.HttpServlet;

public class GetDataServlet extends HttpServlet {
	
	private static final long serialVersionUID = -2970081912950893898L;

}
